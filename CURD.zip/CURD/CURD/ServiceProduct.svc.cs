﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace CURD
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ServiceProduct" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select ServiceProduct.svc or ServiceProduct.svc.cs at the Solution Explorer and start debugging.
    public class ServiceProduct : IServiceProduct
    { DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString());
        public void AddProduct(string ProductName, double Quantiy, double price,string CreatedBY)
        {
            int result = 0;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("Sp_Product_Insert", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ProductName", SqlDbType.NVarChar);
                cmd.Parameters["@ProductName"].Value = ProductName;
                cmd.Parameters.Add("@Quantiy", SqlDbType.Decimal);
                cmd.Parameters["@Quantiy"].Value = Quantiy;
                cmd.Parameters.Add("@Price", SqlDbType.Decimal);
                cmd.Parameters["@Price"].Value = price;
                cmd.Parameters.Add("@CreatedBY", SqlDbType.NVarChar);
                cmd.Parameters["@CreatedBY"].Value = CreatedBY;
                result = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Dispose();
            }
        }
        public void GetProductById(string ProductId)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Sp_GetProductById", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ProductId", SqlDbType.NVarChar);
                cmd.Parameters["@ProductId"].Value = ProductId;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(ds);
                if (ds.Tables.Count > 0)
                { dt = ds.Tables[0]; }

            }
            catch (Exception ex)
            { throw ex; }
            
                 
        }
        public void UpdateProductById(string ProductId, string ProductName, double Quantity, double Price, string CreatedBy)
        {try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("Sp_UpdateProductByProductId", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ProductId", SqlDbType.NVarChar);
                cmd.Parameters["@ProductId"].Value = ProductId;
                cmd.Parameters.Add("@ProductName", SqlDbType.NVarChar);
                cmd.Parameters.Add("@Quantiy", SqlDbType.Decimal);
                cmd.Parameters["@Quantiy"].Value = Quantity;
                cmd.Parameters.Add("@Price", SqlDbType.Decimal);
                cmd.Parameters["@Price"].Value = Price;
                cmd.Parameters.Add("@CreatedBY", SqlDbType.NVarChar);
                cmd.Parameters["@CreatedBY"].Value = CreatedBy;
                int result = cmd.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { conn.Close(); }
        }
        public void DELETEProductByID(string ProductId)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SP_Delete_ProductByProductID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ProductId", SqlDbType.NVarChar);
                cmd.Parameters["@ProductId"].Value = ProductId;
                int rest = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex)
            { throw ex; }
            finally { conn.Dispose(); }
        } 
    }
}
