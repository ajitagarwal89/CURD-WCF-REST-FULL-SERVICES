﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;

namespace CURD
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IServiceProduct" in both code and config file together.
    [ServiceContract]
    public interface IServiceProduct
    {
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "AddProduct/{ProductName}/{Quantiy}/{price}", BodyStyle = WebMessageBodyStyle.Wrapped, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void AddProduct(string product, double  Quantity, double price,string CreatedBY);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "GetProductById/{ProductId}", BodyStyle = WebMessageBodyStyle.Wrapped, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void GetProductById(string ProductId);
        [OperationContract]
        [WebInvoke(Method = "PUT", UriTemplate = "UpdateProductById/{ProductId}/{ProductName}/{Quantiy}/{Price}/{CreatedBY}", BodyStyle = WebMessageBodyStyle.Wrapped, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void UpdateProductById(string ProductId,string ProductName,double Quantity,double Price,string CreatedBy);
        [OperationContract]
        [WebInvoke(Method = "DELETE", UriTemplate = "DELETEProductByID/{ProductId}", BodyStyle = WebMessageBodyStyle.Wrapped, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        void DELETEProductByID(string ProductId);       
    }
  
}
